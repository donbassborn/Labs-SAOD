//---------------------------------------------------------------------------

#ifndef PhoneBookH
#define PhoneBookH
#include "BinaryTree.h"
#include "BinaryTree.cpp"
#include <string>
//---------------------------------------------------------------------------
class PhoneBook : public BinaryTree<long, std::string> {
	public:

};
#endif
